import AdminLayout from './AdminLayout'
import IndexLayout from './IndexLayout'
import LayoutMain from './LayoutMain'

export {
  AdminLayout,
  IndexLayout,
  LayoutMain
}