
export default function Toprated() {
  return (
    <div>top rated</div>
  )
}
