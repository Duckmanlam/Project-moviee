

import Movie_admin from "../../components/admin/Products/Movie-list";

export default function Product() {
  return (
    <div>
      <Movie_admin/>
    </div>
  );
}
